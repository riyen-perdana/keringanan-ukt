import './bootstrap';

import Swal from 'sweetalert2';
import moment from 'moment';
import Pikaday from 'pikaday';

window.Pikaday = Pikaday;
window.moment = moment;
window.Swal = Swal;
