<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title>Sistem Informasi Penyesuaian UKT - Universitas Islam Negeri Sultan Syarif Kasim Riau</title>

        <!-- Fonts -->
        
        <link href='https://fonts.googleapis.com/css?family=Poppins' rel='stylesheet'>

        <!-- Scripts -->
        <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    </head>
    <body class="font-['Poppins']" antialiased>
        
        <div class="bg-white dark:bg-gray-900">
            <div class="flex justify-center h-screen">
                <div class="hidden bg-cover border-r-1 lg:block lg:w-2/3" style="background-image: url('/assets/images/pattern_react.jpg')">
                </div>
                <div class="flex items-center justify-center w-full max-w-* px-6 mx-auto bg-slate-50 lg:w-2/6">
                    <div class="w-full px-6 py-4 mt-6 overflow-hidden sm:max-w-md sm:rounded-lg">
                        <div class="flex flex-col gap-y-5">
                            <div class="flex flex-row items-center gap-x-3">
                                <img src="<?php echo e(asset('assets/images/logo.png')); ?>" alt="" class="h-[60px]">
                                <div class="flex flex-col gap-y-1">
                                    <h3 class="text-sm font-semibold leading-none md:block lg:block text-indigo-950">Sistem Informasi Penyesuaian UKT</h3>
                                    <h4 class="text-xs font-semibold leading-none md:block lg:block text-indigo-950">Universitas Islam Negeri Sultan Syarif Kasim Riau</h4>
                                </div>
                            </div>
                            <?php echo e($slot); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        @livewireScript
    </body>
</html>
<?php /**PATH C:\laragon\www\keringanan-ukt\resources\views/layouts/guest.blade.php ENDPATH**/ ?>