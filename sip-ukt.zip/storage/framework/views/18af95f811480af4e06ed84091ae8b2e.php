<div>
    <?php if (isset($component)) { $__componentOriginal9f64f32e90b9102968f2bc548315018c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9f64f32e90b9102968f2bc548315018c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['name' => 'pendaftar-modal']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'pendaftar-modal']); ?>
        <h2 class="px-6 pt-4 font-semibold text-gray-900 text-normal dark:text-gray-100">
            Verifikasi Data Pendaftar <?php echo e($mahasiswa); ?>

        </h2>
        <section class="px-6 pt-6 pb-4 mb-4 data">
            <div class="flex flex-col gap-2">
                <?php if (isset($component)) { $__componentOriginal72922156f4d73195811f4d7b03c0c0b5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal72922156f4d73195811f4d7b03c0c0b5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button-table','data' => ['xData' => '','xOn:click.prevent' => '$dispatch(\'showModal\',{view:\''.e($surat_permohonan).'\'})','wire:loading.attr' => 'disabled','class' => 'flex flex-row bg-cyan-500 hover:bg-cyan-600']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button-table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['x-data' => '','x-on:click.prevent' => '$dispatch(\'showModal\',{view:\''.e($surat_permohonan).'\'})','wire:loading.attr' => 'disabled','class' => 'flex flex-row bg-cyan-500 hover:bg-cyan-600']); ?>
                    <?php echo e(__('Surat Permohonan Penyesuaian UKT Mahasiswa Kepada Dekan Fakultas')); ?>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal72922156f4d73195811f4d7b03c0c0b5)): ?>
<?php $attributes = $__attributesOriginal72922156f4d73195811f4d7b03c0c0b5; ?>
<?php unset($__attributesOriginal72922156f4d73195811f4d7b03c0c0b5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal72922156f4d73195811f4d7b03c0c0b5)): ?>
<?php $component = $__componentOriginal72922156f4d73195811f4d7b03c0c0b5; ?>
<?php unset($__componentOriginal72922156f4d73195811f4d7b03c0c0b5); ?>
<?php endif; ?>

                <?php if (isset($component)) { $__componentOriginal72922156f4d73195811f4d7b03c0c0b5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal72922156f4d73195811f4d7b03c0c0b5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button-table','data' => ['xData' => '','xOn:click.prevent' => '$dispatch(\'showModal\',{view:\''.e($kartu_keluarga).'\'})','wire:loading.attr' => 'disabled','class' => 'flex flex-row bg-cyan-500 hover:bg-cyan-600']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button-table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['x-data' => '','x-on:click.prevent' => '$dispatch(\'showModal\',{view:\''.e($kartu_keluarga).'\'})','wire:loading.attr' => 'disabled','class' => 'flex flex-row bg-cyan-500 hover:bg-cyan-600']); ?>
                    <?php echo e(__('Scan Asli Kartu Keluarga Mahasiswa')); ?>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal72922156f4d73195811f4d7b03c0c0b5)): ?>
<?php $attributes = $__attributesOriginal72922156f4d73195811f4d7b03c0c0b5; ?>
<?php unset($__attributesOriginal72922156f4d73195811f4d7b03c0c0b5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal72922156f4d73195811f4d7b03c0c0b5)): ?>
<?php $component = $__componentOriginal72922156f4d73195811f4d7b03c0c0b5; ?>
<?php unset($__componentOriginal72922156f4d73195811f4d7b03c0c0b5); ?>
<?php endif; ?>

                <?php if (isset($component)) { $__componentOriginal72922156f4d73195811f4d7b03c0c0b5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal72922156f4d73195811f4d7b03c0c0b5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button-table','data' => ['xData' => '','xOn:click.prevent' => '$dispatch(\'showModal\',{view:\''.e($ktp_ortu).'\'})','wire:loading.attr' => 'disabled','class' => 'flex flex-row bg-cyan-500 hover:bg-cyan-600']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button-table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['x-data' => '','x-on:click.prevent' => '$dispatch(\'showModal\',{view:\''.e($ktp_ortu).'\'})','wire:loading.attr' => 'disabled','class' => 'flex flex-row bg-cyan-500 hover:bg-cyan-600']); ?>
                    <?php echo e(__('Scan Asli Kartu Tanda Penduduk Orang Tua')); ?>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal72922156f4d73195811f4d7b03c0c0b5)): ?>
<?php $attributes = $__attributesOriginal72922156f4d73195811f4d7b03c0c0b5; ?>
<?php unset($__attributesOriginal72922156f4d73195811f4d7b03c0c0b5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal72922156f4d73195811f4d7b03c0c0b5)): ?>
<?php $component = $__componentOriginal72922156f4d73195811f4d7b03c0c0b5; ?>
<?php unset($__componentOriginal72922156f4d73195811f4d7b03c0c0b5); ?>
<?php endif; ?>

                <?php if (isset($component)) { $__componentOriginal72922156f4d73195811f4d7b03c0c0b5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal72922156f4d73195811f4d7b03c0c0b5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button-table','data' => ['xData' => '','xOn:click.prevent' => '$dispatch(\'showModal\',{view:\''.e($gaji_ortu).'\'})','wire:loading.attr' => 'disabled','class' => 'flex flex-row bg-cyan-500 hover:bg-cyan-600']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button-table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['x-data' => '','x-on:click.prevent' => '$dispatch(\'showModal\',{view:\''.e($gaji_ortu).'\'})','wire:loading.attr' => 'disabled','class' => 'flex flex-row bg-cyan-500 hover:bg-cyan-600']); ?>
                    <?php echo e(__('Scan Asli slip gaji orang tua/SKTM dari Lurah setempat')); ?>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal72922156f4d73195811f4d7b03c0c0b5)): ?>
<?php $attributes = $__attributesOriginal72922156f4d73195811f4d7b03c0c0b5; ?>
<?php unset($__attributesOriginal72922156f4d73195811f4d7b03c0c0b5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal72922156f4d73195811f4d7b03c0c0b5)): ?>
<?php $component = $__componentOriginal72922156f4d73195811f4d7b03c0c0b5; ?>
<?php unset($__componentOriginal72922156f4d73195811f4d7b03c0c0b5); ?>
<?php endif; ?>

                <?php if (isset($component)) { $__componentOriginal72922156f4d73195811f4d7b03c0c0b5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal72922156f4d73195811f4d7b03c0c0b5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button-table','data' => ['xData' => '','xOn:click.prevent' => '$dispatch(\'showModal\',{view:\''.e($rekening_listrik).'\'})','wire:loading.attr' => 'disabled','class' => 'flex flex-row bg-cyan-500 hover:bg-cyan-600']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button-table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['x-data' => '','x-on:click.prevent' => '$dispatch(\'showModal\',{view:\''.e($rekening_listrik).'\'})','wire:loading.attr' => 'disabled','class' => 'flex flex-row bg-cyan-500 hover:bg-cyan-600']); ?>
                    <?php echo e(__('Scan Asli Rekening Listrik Selama 2 Bulan')); ?>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal72922156f4d73195811f4d7b03c0c0b5)): ?>
<?php $attributes = $__attributesOriginal72922156f4d73195811f4d7b03c0c0b5; ?>
<?php unset($__attributesOriginal72922156f4d73195811f4d7b03c0c0b5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal72922156f4d73195811f4d7b03c0c0b5)): ?>
<?php $component = $__componentOriginal72922156f4d73195811f4d7b03c0c0b5; ?>
<?php unset($__componentOriginal72922156f4d73195811f4d7b03c0c0b5); ?>
<?php endif; ?>

                <?php if (isset($component)) { $__componentOriginal72922156f4d73195811f4d7b03c0c0b5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal72922156f4d73195811f4d7b03c0c0b5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button-table','data' => ['xData' => '','xOn:click.prevent' => '$dispatch(\'showModal\',{view:\''.e($skk_ortu).'\'})','wire:loading.attr' => 'disabled','class' => 'flex flex-row bg-cyan-500 hover:bg-cyan-600']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button-table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['x-data' => '','x-on:click.prevent' => '$dispatch(\'showModal\',{view:\''.e($skk_ortu).'\'})','wire:loading.attr' => 'disabled','class' => 'flex flex-row bg-cyan-500 hover:bg-cyan-600']); ?>
                    <?php echo e(__('Surat Keterangan Kematian/Sakit Permanen/PHK/Pailit Orang Tua')); ?>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal72922156f4d73195811f4d7b03c0c0b5)): ?>
<?php $attributes = $__attributesOriginal72922156f4d73195811f4d7b03c0c0b5; ?>
<?php unset($__attributesOriginal72922156f4d73195811f4d7b03c0c0b5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal72922156f4d73195811f4d7b03c0c0b5)): ?>
<?php $component = $__componentOriginal72922156f4d73195811f4d7b03c0c0b5; ?>
<?php unset($__componentOriginal72922156f4d73195811f4d7b03c0c0b5); ?>
<?php endif; ?>

                <?php if (isset($component)) { $__componentOriginal72922156f4d73195811f4d7b03c0c0b5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal72922156f4d73195811f4d7b03c0c0b5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button-table','data' => ['xData' => '','xOn:click.prevent' => '$dispatch(\'showModal\',{view:\''.e($ft_ruangtamu).'\'})','wire:loading.attr' => 'disabled','class' => 'flex flex-row bg-cyan-500 hover:bg-cyan-600']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button-table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['x-data' => '','x-on:click.prevent' => '$dispatch(\'showModal\',{view:\''.e($ft_ruangtamu).'\'})','wire:loading.attr' => 'disabled','class' => 'flex flex-row bg-cyan-500 hover:bg-cyan-600']); ?>
                    <?php echo e(__('Foto Ruang Tamu Rumah Orang Tua/Wali')); ?>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal72922156f4d73195811f4d7b03c0c0b5)): ?>
<?php $attributes = $__attributesOriginal72922156f4d73195811f4d7b03c0c0b5; ?>
<?php unset($__attributesOriginal72922156f4d73195811f4d7b03c0c0b5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal72922156f4d73195811f4d7b03c0c0b5)): ?>
<?php $component = $__componentOriginal72922156f4d73195811f4d7b03c0c0b5; ?>
<?php unset($__componentOriginal72922156f4d73195811f4d7b03c0c0b5); ?>
<?php endif; ?>

                <?php if (isset($component)) { $__componentOriginal72922156f4d73195811f4d7b03c0c0b5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal72922156f4d73195811f4d7b03c0c0b5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button-table','data' => ['xData' => '','xOn:click.prevent' => '$dispatch(\'showModal\',{view:\''.e($ft_kmrtidur).'\'})','wire:loading.attr' => 'disabled','class' => 'flex flex-row bg-cyan-500 hover:bg-cyan-600']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button-table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['x-data' => '','x-on:click.prevent' => '$dispatch(\'showModal\',{view:\''.e($ft_kmrtidur).'\'})','wire:loading.attr' => 'disabled','class' => 'flex flex-row bg-cyan-500 hover:bg-cyan-600']); ?>
                    <?php echo e(__('Foto Kamar Tidur Rumah Orang Tua/Wali')); ?>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal72922156f4d73195811f4d7b03c0c0b5)): ?>
<?php $attributes = $__attributesOriginal72922156f4d73195811f4d7b03c0c0b5; ?>
<?php unset($__attributesOriginal72922156f4d73195811f4d7b03c0c0b5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal72922156f4d73195811f4d7b03c0c0b5)): ?>
<?php $component = $__componentOriginal72922156f4d73195811f4d7b03c0c0b5; ?>
<?php unset($__componentOriginal72922156f4d73195811f4d7b03c0c0b5); ?>
<?php endif; ?>

                <?php if (isset($component)) { $__componentOriginal72922156f4d73195811f4d7b03c0c0b5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal72922156f4d73195811f4d7b03c0c0b5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button-table','data' => ['xData' => '','xOn:click.prevent' => '$dispatch(\'showModal\',{view:\''.e($ft_ruangklrg).'\'})','wire:loading.attr' => 'disabled','class' => 'flex flex-row bg-cyan-500 hover:bg-cyan-600']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button-table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['x-data' => '','x-on:click.prevent' => '$dispatch(\'showModal\',{view:\''.e($ft_ruangklrg).'\'})','wire:loading.attr' => 'disabled','class' => 'flex flex-row bg-cyan-500 hover:bg-cyan-600']); ?>
                    <?php echo e(__('Foto Ruang Keluarga Orang Tua/Wali')); ?>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal72922156f4d73195811f4d7b03c0c0b5)): ?>
<?php $attributes = $__attributesOriginal72922156f4d73195811f4d7b03c0c0b5; ?>
<?php unset($__attributesOriginal72922156f4d73195811f4d7b03c0c0b5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal72922156f4d73195811f4d7b03c0c0b5)): ?>
<?php $component = $__componentOriginal72922156f4d73195811f4d7b03c0c0b5; ?>
<?php unset($__componentOriginal72922156f4d73195811f4d7b03c0c0b5); ?>
<?php endif; ?>

                <?php if (isset($component)) { $__componentOriginal72922156f4d73195811f4d7b03c0c0b5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal72922156f4d73195811f4d7b03c0c0b5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button-table','data' => ['xData' => '','xOn:click.prevent' => '$dispatch(\'showModal\',{view:\''.e($ft_dapur).'\'})','wire:loading.attr' => 'disabled','class' => 'flex flex-row bg-cyan-500 hover:bg-cyan-600']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button-table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['x-data' => '','x-on:click.prevent' => '$dispatch(\'showModal\',{view:\''.e($ft_dapur).'\'})','wire:loading.attr' => 'disabled','class' => 'flex flex-row bg-cyan-500 hover:bg-cyan-600']); ?>
                    <?php echo e(__('Foto Dapur Rumah Orang Tua/Wali')); ?>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal72922156f4d73195811f4d7b03c0c0b5)): ?>
<?php $attributes = $__attributesOriginal72922156f4d73195811f4d7b03c0c0b5; ?>
<?php unset($__attributesOriginal72922156f4d73195811f4d7b03c0c0b5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal72922156f4d73195811f4d7b03c0c0b5)): ?>
<?php $component = $__componentOriginal72922156f4d73195811f4d7b03c0c0b5; ?>
<?php unset($__componentOriginal72922156f4d73195811f4d7b03c0c0b5); ?>
<?php endif; ?>

                <?php if (isset($component)) { $__componentOriginal72922156f4d73195811f4d7b03c0c0b5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal72922156f4d73195811f4d7b03c0c0b5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button-table','data' => ['xData' => '','xOn:click.prevent' => '$dispatch(\'showModal\',{view:\''.e($ft_dpnrumah).'\'})','wire:loading.attr' => 'disabled','class' => 'flex flex-row bg-cyan-500 hover:bg-cyan-600']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button-table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['x-data' => '','x-on:click.prevent' => '$dispatch(\'showModal\',{view:\''.e($ft_dpnrumah).'\'})','wire:loading.attr' => 'disabled','class' => 'flex flex-row bg-cyan-500 hover:bg-cyan-600']); ?>
                    <?php echo e(__('Foto Keseluruhan Tampak Depan Rumah Orang Tua/Wali')); ?>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal72922156f4d73195811f4d7b03c0c0b5)): ?>
<?php $attributes = $__attributesOriginal72922156f4d73195811f4d7b03c0c0b5; ?>
<?php unset($__attributesOriginal72922156f4d73195811f4d7b03c0c0b5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal72922156f4d73195811f4d7b03c0c0b5)): ?>
<?php $component = $__componentOriginal72922156f4d73195811f4d7b03c0c0b5; ?>
<?php unset($__componentOriginal72922156f4d73195811f4d7b03c0c0b5); ?>
<?php endif; ?>

                <?php if (isset($component)) { $__componentOriginal72922156f4d73195811f4d7b03c0c0b5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal72922156f4d73195811f4d7b03c0c0b5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button-table','data' => ['xData' => '','xOn:click.prevent' => '$dispatch(\'showModal\',{view:\''.e($sk_tdkbs).'\'})','wire:loading.attr' => 'disabled','class' => 'flex flex-row bg-cyan-500 hover:bg-cyan-600']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button-table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['x-data' => '','x-on:click.prevent' => '$dispatch(\'showModal\',{view:\''.e($sk_tdkbs).'\'})','wire:loading.attr' => 'disabled','class' => 'flex flex-row bg-cyan-500 hover:bg-cyan-600']); ?>
                    <?php echo e(__('Surat Keterangan Tidak Sedang Menerima Beasiswa')); ?>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal72922156f4d73195811f4d7b03c0c0b5)): ?>
<?php $attributes = $__attributesOriginal72922156f4d73195811f4d7b03c0c0b5; ?>
<?php unset($__attributesOriginal72922156f4d73195811f4d7b03c0c0b5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal72922156f4d73195811f4d7b03c0c0b5)): ?>
<?php $component = $__componentOriginal72922156f4d73195811f4d7b03c0c0b5; ?>
<?php unset($__componentOriginal72922156f4d73195811f4d7b03c0c0b5); ?>
<?php endif; ?>

                <?php if (isset($component)) { $__componentOriginal72922156f4d73195811f4d7b03c0c0b5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal72922156f4d73195811f4d7b03c0c0b5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button-table','data' => ['xData' => '','xOn:click.prevent' => '$dispatch(\'showModal\',{view:\''.e($spkd).'\'})','wire:loading.attr' => 'disabled','class' => 'flex flex-row bg-cyan-500 hover:bg-cyan-600']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button-table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['x-data' => '','x-on:click.prevent' => '$dispatch(\'showModal\',{view:\''.e($spkd).'\'})','wire:loading.attr' => 'disabled','class' => 'flex flex-row bg-cyan-500 hover:bg-cyan-600']); ?>
                    <?php echo e(__('Surat Keterangan Kebenaran Data')); ?>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal72922156f4d73195811f4d7b03c0c0b5)): ?>
<?php $attributes = $__attributesOriginal72922156f4d73195811f4d7b03c0c0b5; ?>
<?php unset($__attributesOriginal72922156f4d73195811f4d7b03c0c0b5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal72922156f4d73195811f4d7b03c0c0b5)): ?>
<?php $component = $__componentOriginal72922156f4d73195811f4d7b03c0c0b5; ?>
<?php unset($__componentOriginal72922156f4d73195811f4d7b03c0c0b5); ?>
<?php endif; ?>

            </div>
        </section>
        <section class="form_data">
            <form class="px-6 pt-0 pb-4 mb-4 bg-white rounded" wire:submit="save" wire:loading.attr="disabled">
                <?php echo csrf_field(); ?>
                <div class="mb-2">
                    <?php if (isset($component)) { $__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-label','data' => ['for' => 'is_setuju','value' => __('Persetujuan Pengajuan'),'class' => 'mb-2 font-semibold']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'is_setuju','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Persetujuan Pengajuan')),'class' => 'mb-2 font-semibold']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581)): ?>
<?php $attributes = $__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581; ?>
<?php unset($__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581)): ?>
<?php $component = $__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581; ?>
<?php unset($__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581); ?>
<?php endif; ?>
                      <select wire:model="is_setuju" class="w-full px-3 py-2 text-sm leading-tight text-gray-700 border border-gray-300 rounded shadow appearance-none focus:border-indigo-500 focus:ring-indigo-500 focus:outline-none focus:shadow-outline">
                        <option value=""><?php echo e(__('Pilih Persetujuan')); ?></option>
                        <option value="Y"><?php echo e(__('Setuju Pengajuan')); ?></option>
                        <option value="N"><?php echo e(__('Tolak Pengajuan')); ?></option>
                      </select>
                      <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->get('is_setuju'),'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('is_setuju')),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                </div>
                <div class="mb-2">
                    <?php if (isset($component)) { $__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-label','data' => ['for' => 'komentar','value' => __('Catatan Persetujuan'),'class' => 'mb-2 font-semibold']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'komentar','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Catatan Persetujuan')),'class' => 'mb-2 font-semibold']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581)): ?>
<?php $attributes = $__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581; ?>
<?php unset($__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581)): ?>
<?php $component = $__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581; ?>
<?php unset($__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581); ?>
<?php endif; ?>
                    <textarea wire:model="komentar" class="w-full px-3 py-2 text-xs leading-tight text-gray-700 border border-gray-300 rounded shadow appearance-none focus:border-indigo-500 focus:ring-indigo-500 focus:outline-none focus:shadow-outline"></textarea>
                    <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->get('komentar'),'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('komentar')),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                </div>
                <div class="flex items-center justify-end mt-10 gap-x-2">
                    <?php if (isset($component)) { $__componentOriginald411d1792bd6cc877d687758b753742c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald411d1792bd6cc877d687758b753742c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-button','data' => ['wire:loading.attr' => 'disabled']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('primary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:loading.attr' => 'disabled']); ?>
                        <!--[if BLOCK]><![endif]--><?php if($tombol === 'Ubah'): ?>
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-3.5 h-3.5 me-2">
                                <path stroke-linecap="round" stroke-linejoin="round" d="m16.862 4.487 1.687-1.688a1.875 1.875 0 1 1 2.652 2.652L10.582 16.07a4.5 4.5 0 0 1-1.897 1.13L6 18l.8-2.685a4.5 4.5 0 0 1 1.13-1.897l8.932-8.931Zm0 0L19.5 7.125M18 14v4.75A2.25 2.25 0 0 1 15.75 21H5.25A2.25 2.25 0 0 1 3 18.75V8.25A2.25 2.25 0 0 1 5.25 6H10" />
                            </svg>
                        <?php else: ?>
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-3.5 h-3.5 me-2">
                                <path stroke-linecap="round" stroke-linejoin="round" d="m4.5 12.75 6 6 9-13.5" />
                            </svg>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <?php echo e($tombol); ?>

                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $attributes = $__attributesOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__attributesOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $component = $__componentOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__componentOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.secondary-button','data' => ['wire:click' => 'resetForm']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('secondary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'resetForm']); ?>
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-3.5 h-3.5 me-2">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M6 18 18 6M6 6l12 12" />
                        </svg>
                          <?php echo e(__('Batal')); ?>

                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $attributes = $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $component = $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
                </div>
            </form>
        </section>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $attributes = $__attributesOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__attributesOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $component = $__componentOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__componentOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
</div>

<?php /**PATH C:\laragon\www\keringanan-ukt\resources\views/livewire/pendaftar/pendaftar-modal.blade.php ENDPATH**/ ?>