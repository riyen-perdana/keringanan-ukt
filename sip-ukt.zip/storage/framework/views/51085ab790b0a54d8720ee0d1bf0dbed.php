<div>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="text-xl font-semibold leading-tight text-gray-800">
            <?php echo e(__('Pendaftar Penyesuaian UKT')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="mx-auto max-w-7xl sm:px-6 lg:px-8">
            <div class="overflow-hidden bg-white shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <section class="flex flex-row pendaftar-table">
                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('pendaftar.pendaftar-table');

$__html = app('livewire')->mount($__name, $__params, 'lw-2651249592-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    </section>
                    <section class="pendaftar-modal">
                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('pendaftar.pendaftar-modal');

$__html = app('livewire')->mount($__name, $__params, 'lw-2651249592-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    </section>
                    <section class="pendaftar-view-bukti">
                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('pendaftar.pendaftar-modal-view');

$__html = app('livewire')->mount($__name, $__params, 'lw-2651249592-2', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    </section>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\keringanan-ukt\resources\views/livewire/pendaftar/index.blade.php ENDPATH**/ ?>