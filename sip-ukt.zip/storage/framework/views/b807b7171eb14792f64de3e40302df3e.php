<button <?php echo e($attributes->merge(['type' => 'button', 'class' => 'class="inline-flex items-center px-3 py-1 text-xs font-medium text-center text-white rounded-lg'])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH C:\laragon\www\keringanan-ukt\resources\views/components/button-table.blade.php ENDPATH**/ ?>