<div wire:poll>
    <div class="container max-w-6xl mx-auto">
        <div class="grid grid-cols-1 gap-7 md:grid-cols-2">
            <section class="bio">
                <div class="p-5 bg-white rounded shadow-xl">
                    <section class="mb-2 text-sm font-semibold header">
                        Biodata Mahasiswa
                    </section>
                    <hr class="h-px mb-3 bg-gray-200 border-0 dark:bg-gray-700">
                    <section class="flex flex-row gap-5 bio">
                        <?php
                            $url = str_replace('uc', 'thumbnail', Auth::guard('mahasiswa')->user()->foto);
                        ?>
                        <img src="<?php echo e($url); ?>" alt="" class="w-20 h-20 rounded-2xl ">
                        <section class="w-full text-xs uppercase data">
                            <div class="flex flex-col mb-2">
                                <div class="font-semibold">
                                    Nomor Induk Mahasiswa
                                </div>
                                <div>
                                    <?php echo e(Auth::guard('mahasiswa')->user()->nim); ?>

                                </div>
                            </div>
                            <hr class="h-px mb-3 bg-gray-200 border-0 dark:bg-gray-700">
                            <div class="flex flex-col mb-2">
                                <div class="font-semibold">
                                    Nama
                                </div>
                                <div>
                                    <?php echo e(Auth::guard('mahasiswa')->user()->nama); ?>

                                </div>
                            </div>
                            <hr class="h-px mb-3 bg-gray-200 border-0 dark:bg-gray-700">
                            <div class="flex flex-col mb-2">
                                <div class="font-semibold">
                                    Program Studi
                                </div>
                                <div>
                                    <?php echo e(Auth::guard('mahasiswa')->user()->prodi->name_prodi); ?>

                                </div>
                            </div>
                            <hr class="h-px mb-3 bg-gray-200 border-0 dark:bg-gray-700">
                            <div class="flex flex-col mb-2">
                                <div class="font-semibold">
                                    Fakultas
                                </div>
                                <div>
                                    <?php echo e(Auth::guard('mahasiswa')->user()->prodi->fakultas->name); ?>

                                </div>
                            </div>
                            <hr class="h-px mb-3 bg-gray-200 border-0 dark:bg-gray-700">
                            <div class="flex flex-col mb-2">
                                <div class="font-semibold">
                                    Semester
                                </div>
                                <div>
                                    <?php echo e(Auth::guard('mahasiswa')->user()->semester); ?>

                                </div>
                            </div>
                            <hr class="h-px mb-3 bg-gray-200 border-0 dark:bg-gray-700">
                            <div class="flex flex-col mb-2">
                                <div class="font-semibold">
                                    Kelompok UKT - Besaran UKT
                                </div>
                                <div>
                                    UKT <?php echo e(Auth::guard('mahasiswa')->user()->ukt); ?> -
                                    <?php echo e(format_rupiah(Auth::guard('mahasiswa')->user()->jml_ukt_awal)); ?>

                                </div>
                            </div>
                            <hr class="h-px mb-3 bg-gray-200 border-0 dark:bg-gray-700">
                        </section>
                    </section>
                </div>
            </section>
            <section class="riwayat">
                <div class="min-h-full p-5 overflow-hidden bg-white rounded shadow-xl">
                    <section class="mb-2 text-sm font-semibold header">
                        Riwayat Pengajuan
                    </section>
                    <hr class="h-px mb-3 bg-gray-200 border-0 dark:bg-gray-700">
                    <section class="tabel">
                        <div class="flex flex-row text-xs gap-y-2">
                            <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <table class="table w-full leading-normal border-none">
                                    <th>
                                        <tr>
                                            <td class="text-left">Tahun</td>
                                            <td class="font-bold text-right"><?php echo e($item->tahun); ?></td>
                                        </tr>
                                        <tr>
                                            <td class="text-left">Status Pendaftaran</td>
                                            <?php
                                                $date = date('Y-m-d');
                                            ?>
                                            <!--[if BLOCK]><![endif]--><?php if($item->daftar_buka <= $date && $item->daftar_tutup >= $date): ?>
                                                <td class="font-semibold text-right text-green-500">Buka</td>
                                            <?php else: ?>
                                                <td class="font-semibold text-right text-red-500">Tutup</td>
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        </tr>
                                        <tr>
                                            <td class="text-left">Status Pengajuan</td>
                                            <!--[if BLOCK]><![endif]--><?php $__empty_2 = true; $__currentLoopData = $item->pengajuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                                <?php
                                                    $ajk = true;
                                                ?>
                                                <td class="font-semibold text-right text-green-500">Sudah Mengajukan</td>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                                <td class="font-semibold text-right text-red-500">Belum Mengajukan</td>
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        </tr>
                                        <tr>
                                            <td class="text-left">Tanggal Pengajuan</td>
                                            <!--[if BLOCK]><![endif]--><?php $__empty_2 = true; $__currentLoopData = $item->pengajuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                                <td class="font-semibold text-right text-green-500"><?php echo e(tanggal_indonesia($aj->created_at)); ?></td>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                                <td class="font-semibold text-right text-red-500"><?php echo e('-'); ?></td>
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        </tr>
                                        <tr>
                                            <td class="text-left"></td>
                                            <td class="pt-2 font-semibold text-right">
                                                <!--[if BLOCK]><![endif]--><?php if(($item->daftar_buka <= $date && $item->daftar_tutup >= $date) && $ajk !==true): ?>
                                                    <?php if (isset($component)) { $__componentOriginal00b6af2ae42b4243b22df708fc13ac21 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal00b6af2ae42b4243b22df708fc13ac21 = $attributes; } ?>
<?php $component = App\View\Components\LinkButton::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('link-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\LinkButton::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'bg-sky-500 ms-1 hover:bg-sky-400 focus:bg-sky-400 active:bg-sky-400','href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('pengajuan.index')),'wire:navigate' => true]); ?>
                                                        <svg xmlns="http://www.w3.org/2000/svg" fill="none"
                                                            viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"
                                                            class="w-3.5 h-3.5 me-2">
                                                            <path stroke-linecap="round" stroke-linejoin="round"
                                                            d="M6.429 9.75 2.25 12l4.179 2.25m0-4.5 5.571 3 5.571-3m-11.142 0L2.25 7.5 12 2.25l9.75 5.25-4.179 2.25m0 0L21.75 12l-4.179 2.25m0 0 4.179 2.25L12 21.75 2.25 16.5l4.179-2.25m11.142 0-5.571 3-5.571-3" />
                                                        </svg>
                                                        <?php echo e(__('Klik Disini Untuk Mengajukan')); ?>

                                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal00b6af2ae42b4243b22df708fc13ac21)): ?>
<?php $attributes = $__attributesOriginal00b6af2ae42b4243b22df708fc13ac21; ?>
<?php unset($__attributesOriginal00b6af2ae42b4243b22df708fc13ac21); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal00b6af2ae42b4243b22df708fc13ac21)): ?>
<?php $component = $__componentOriginal00b6af2ae42b4243b22df708fc13ac21; ?>
<?php unset($__componentOriginal00b6af2ae42b4243b22df708fc13ac21); ?>
<?php endif; ?>
                                                <?php else: ?>
                                                    <?php if (isset($component)) { $__componentOriginal00b6af2ae42b4243b22df708fc13ac21 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal00b6af2ae42b4243b22df708fc13ac21 = $attributes; } ?>
<?php $component = App\View\Components\LinkButton::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('link-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\LinkButton::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'bg-red-500 cursor-not-allowed pointer-events-none ms-1 hover:bg-red-400 focus:bg-red-400 active:bg-red-400','href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('dashboard')),'wire:navigate' => true]); ?>
                                                            <svg xmlns="http://www.w3.org/2000/svg" fill="none"
                                                            viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"
                                                            class="w-3.5 h-3.5 me-2">
                                                            <path stroke-linecap="round" stroke-linejoin="round"
                                                            d="M6.429 9.75 2.25 12l4.179 2.25m0-4.5 5.571 3 5.571-3m-11.142 0L2.25 7.5 12 2.25l9.75 5.25-4.179 2.25m0 0L21.75 12l-4.179 2.25m0 0 4.179 2.25L12 21.75 2.25 16.5l4.179-2.25m11.142 0-5.571 3-5.571-3" />
                                                        </svg>
                                                    <?php echo e(__('Pendaftaran Ditutup')); ?>

                                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal00b6af2ae42b4243b22df708fc13ac21)): ?>
<?php $attributes = $__attributesOriginal00b6af2ae42b4243b22df708fc13ac21; ?>
<?php unset($__attributesOriginal00b6af2ae42b4243b22df708fc13ac21); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal00b6af2ae42b4243b22df708fc13ac21)): ?>
<?php $component = $__componentOriginal00b6af2ae42b4243b22df708fc13ac21; ?>
<?php unset($__componentOriginal00b6af2ae42b4243b22df708fc13ac21); ?>
<?php endif; ?>
                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            </td>
                                        </tr>
                                    </th>
                                </table>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <div class="text-sm font-semibold">Data Tidak Tersedia</div>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    </section>
                </div>
            </section>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\keringanan-ukt\resources\views/livewire/mahasiswa/index.blade.php ENDPATH**/ ?>