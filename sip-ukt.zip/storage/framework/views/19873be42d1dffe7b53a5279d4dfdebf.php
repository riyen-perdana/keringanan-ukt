
<div class="flex flex-row items-center gap-x-3">
    <img src="<?php echo e(asset('assets/images/logo.png')); ?>" alt="" class="h-[60px]">
    <div class="flex flex-col gap-y-1">
        <h3 class="text-sm font-semibold leading-none md:block lg:block text-indigo-950">Sistem Informasi Penyesuaian UKT</h3>
        <h4 class="text-xs font-semibold leading-none md:block lg:block text-indigo-950">Universitas Islam Negeri Sultan Syarif Kasim Riau</h4>
    </div>
</div>
<?php /**PATH C:\laragon\www\keringanan-ukt\resources\views/components/application-logo.blade.php ENDPATH**/ ?>