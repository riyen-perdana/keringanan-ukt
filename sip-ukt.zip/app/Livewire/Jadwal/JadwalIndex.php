<?php

namespace App\Livewire\Jadwal;

use Livewire\Component;

class JadwalIndex extends Component
{
    public function render()
    {
        return view('livewire.jadwal.index');
    }
}
