<?php

namespace App\Livewire\Fakultas;

use Livewire\Component;

class FakultasIndex extends Component
{
    public function render()
    {
        return view('livewire.fakultas.index');
    }
}
