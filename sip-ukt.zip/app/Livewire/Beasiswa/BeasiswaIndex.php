<?php

namespace App\Livewire\Beasiswa;

use Livewire\Component;

class BeasiswaIndex extends Component
{
    public function render()
    {
        return view('livewire.beasiswa.index');
    }
}
