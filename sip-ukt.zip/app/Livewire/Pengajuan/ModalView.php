<?php

namespace App\Livewire\Pengajuan;

use Livewire\Component;

class ModalView extends Component
{

    public function render()
    {
        return view('livewire.pengajuan.modal-view');
    }

}
