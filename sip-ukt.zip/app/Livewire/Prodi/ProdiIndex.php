<?php

namespace App\Livewire\Prodi;

use Livewire\Component;

class ProdiIndex extends Component
{
    public function render()
    {
        return view('livewire.prodi.index');
    }
}
